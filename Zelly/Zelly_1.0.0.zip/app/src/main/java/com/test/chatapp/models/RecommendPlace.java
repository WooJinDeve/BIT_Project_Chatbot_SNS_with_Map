package com.test.chatapp.models;

import android.location.Address;

public class RecommendPlace {
    public int idPlace;
    public Double lat, lon;
    public String placeName, hashTags, image;
    public int age;
    public Address address;
}
