package com.test.chatapp.models;

import java.util.Date;

public class ChatMessage {
    public String documentId;
    public String senderId, receiverId, message, dateTime;
    public String check;
    public Date dateObject;
    public String conversionId, conversionName, conversionImage;
}
