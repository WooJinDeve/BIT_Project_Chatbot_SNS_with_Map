package com.test.chatapp.models;

public class UserSchedule {
    public String document;
    public String time;
    public String[] days = new String[]{"0","0","0","0","0","0","0"};
    public boolean state;
    public boolean repeat;
}