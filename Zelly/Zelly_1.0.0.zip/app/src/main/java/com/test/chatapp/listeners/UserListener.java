package com.test.chatapp.listeners;

import com.test.chatapp.models.User;

public interface UserListener {
    void onUserClicked(User user);
}
