package com.test.chatapp.listeners;

import com.test.chatapp.models.User;

public interface ConversionListener {
    void onConversionClicked(User user);
}
