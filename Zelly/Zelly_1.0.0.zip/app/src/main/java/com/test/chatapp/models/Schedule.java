package com.test.chatapp.models;

public class Schedule {
    public String friendName, myName, calendarContent, calendarDate, calendarExplain, calendarFriend, calendarMe, calendarLocation;
    public int startcalendarTimeHour, startcalendarTimeMinute, endcalendarTimeHour, endcalendarTimeMinute;
    public double calendarLat, calendarLon;
}
