package com.test.chatapp.models;

public class Place {
    public String name, category, image, address;
}
