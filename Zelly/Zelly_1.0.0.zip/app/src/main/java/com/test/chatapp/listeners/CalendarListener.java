package com.test.chatapp.listeners;


import com.test.chatapp.models.Calendar;

public interface CalendarListener {
    void onCalendarClicked(Calendar calendar);
}
