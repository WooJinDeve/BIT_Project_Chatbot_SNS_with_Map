package com.test.chatapp.models;

public class Restaurant {
    public String name, imgSource, rating;
}
